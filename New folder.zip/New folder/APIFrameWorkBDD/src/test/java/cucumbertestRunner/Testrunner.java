package cucumbertestRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src\\test\\java\\features", 
		//plugin = "json:target/jsonReports/cucumber-report.json", 
		glue = "stepdefinitions",
	    plugin = {
			            "pretty",
			            "json:target/cucumber-report/cucumber.json",
			            "html:target/cucumber-report/cucumber.html"
			            
			         // In glue you just need to give the name of the package but remember that, the
			         // package in which this test runner is created is same and the package in which
			         // step definition is present should have same parent if it is not done you will need to give the exact location till the package of step definition

			            
			            
			    }
// tags = "@AddPlace"

)

public class Testrunner {

}
