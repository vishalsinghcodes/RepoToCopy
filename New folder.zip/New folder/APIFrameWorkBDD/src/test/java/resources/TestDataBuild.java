package resources;

import java.util.Arrays;

import pojo.AddPlace;
import pojo.LocationchildPOJO;

public class TestDataBuild {
	
	public AddPlace addPlacePayload(String name, String languare, String address ) {
		AddPlace p = new AddPlace();
		LocationchildPOJO lp = new LocationchildPOJO();
		lp.setLat(-23.4554);
		lp.setLng(45.23655);
		String[] typeList = { "dog parh", "houses", "residents" };
		p.setAccuracy(50);
		p.setAddress(address);
		p.setLanguage(languare);
		p.setName(name);
		p.setPhone_number("9658645855");
		p.setTypes(Arrays.asList(typeList));
		p.setLocation(lp);
		p.setWebsite("www.google.com");
		return p;
	}
	
	
	public static String deletePlacePayload(String placeID) {
		return "{\r\n"
				+ "    \"place_id\": \""+placeID+"\"\r\n"
				+ "}";
	}

}
