package stepdefinitions;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.Arrays;

import org.junit.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static org.junit.Assert.*; // Remember to add this package as additional 

import pojo.AddPlace;
import pojo.LocationchildPOJO;
import resources.APIResources;
import resources.TestDataBuild;
import resources.Utilities;

public class stepDefinition extends Utilities {
	RequestSpecification requestWithBody;
	ResponseSpecification respspec;
	Response response;
	TestDataBuild data = new TestDataBuild();
	static String placeid;
//	@Given("Add Place Payload")
//	public void add_place_payload() throws IOException {
//		//requestWithBody = given().spec(requestspecification()).body(data.addPlacePayload());
//
//	}

	// this step for parameterized scenario of above request we can make single also but to show I have created 2 separate and have commented previous
	@Given("^Add Place Payload with (.+),(.+),(.+)$")
	public void add_Place_Payload_with(String name, String language, String address) throws IOException {
		requestWithBody = given().spec(requestspecification()).body(data.addPlacePayload(name, language,address));
	}

	@When("User calls {string} using {string} http request")
	public void user_calls_using_post_http_request(String resource, String method) {
		APIResources resourceAPI =   APIResources.valueOf(resource);// yaha value constructor me gai new object jab bana
		// ye new object ban gaya jsime resource ki value pass ho gai  
		respspec = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
		
		if(method.equalsIgnoreCase("POST")) {
		response = requestWithBody.when().post(resourceAPI.getResource());
		}else if(method.equalsIgnoreCase("GET")) {
			response = requestWithBody.when().get(resourceAPI.getResource());
		}
	}

	@Then("The API call got success with status code {int}")
	public void the_api_call_got_success_with_status_code(Integer int1) {
		assertEquals(200, response.getStatusCode());
	}

	@Then("{string} in response body is {string}")
	public void in_response_body_is(String key, String expectedvalue) {	
		assertEquals(getJsonPathValue(response, key), expectedvalue);
	}
	
	@And("verify place_Id created maps to {string} using {string}")
    public void verifyPlaceIdMapsToName(String expectedName, String requestname) throws IOException {
		placeid = getJsonPathValue(response, "place_id");
		requestWithBody = given().spec(requestspecification()).queryParam("place_id", placeid);
		user_calls_using_post_http_request(requestname, "GET");
		String name = getJsonPathValue(response, "name");
		assertEquals(name, expectedName);
    }
	
	@Given("DeletePlace Payload")
    public void deletePlacePayload() throws IOException {
		requestWithBody = given().spec(requestspecification()).body(data.deletePlacePayload(placeid));
    } 

}
