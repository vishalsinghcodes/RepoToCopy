package stepdef;

import java.util.List;
import java.util.Map;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition {
	
	
	@Given("Print First Line")
	public void print_first_line() {
		System.out.println("This is first Step");
	   
	}
	
	
	@When("Print this is when statement:")
	public void print_this_is_when_statement(io.cucumber.datatable.DataTable dataTable) {
		System.out.println("This is when step with data table");
		List<Map<String,String>> data = dataTable.asMaps(String.class,String.class);
		for(Map<String,String> dt : data) {
			System.out.println(dt.get("name"));
			System.out.println(dt.get("password"));
		}
		   
	}
	
	@Then("This is then")
	public void this_is_then() {
		System.out.println("This is then step");
	    
	}
	
	

}
