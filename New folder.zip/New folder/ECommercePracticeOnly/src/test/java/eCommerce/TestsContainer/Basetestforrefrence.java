package eCommerce.TestsContainer;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import eCommerce.PageObjects.CheckOutPage;
import eCommerce.PageObjects.ConfirmationPage;
import eCommerce.PageObjects.OrderHistoryPageEcommerce;
import eCommerce.PageObjects.PaymentPage;
import eCommerce.PageObjects.ProductPage;
import eCommerce.TestComponents.BaseTest;

public class Basetestforrefrence extends BaseTest {
	String productName = "ADIDAS";
	String country = "India";

	@Test(groups = { "Sanity", "Smoke" },dataProvider = "getData")
	public void fullFlowTest(HashMap<String, String>  input) throws IOException, InterruptedException {
		// launchApplicationEcommerce();
		ProductPage productPage = landingPage.login(input.get("un"), input.get("pw"));
		productPage.buyProduct(input.get("pro"));
		Thread.sleep(2000);
		CheckOutPage checkOutPage = productPage.clickOnCartButton();
		Thread.sleep(2000);
		Assert.assertTrue(checkOutPage.verifyProduct(input.get("pro")));
		PaymentPage paymentPage = checkOutPage.clickCheckoutButton();
		paymentPage.typeInCountryTextBox("Ind");
		paymentPage.SelectCountry(country);
		ConfirmationPage confirmationPage = paymentPage.clickPlaceOrderButton();
		Assert.assertTrue(confirmationPage.verifyHeaderText("THANKYOU FOR THE ORDER."));
		System.out.println(confirmationPage.getOrderNumber());
	}
	
	

	@Test(dependsOnMethods = "fullFlowTest",dataProvider = "getData",groups = {"Smoke"})
	public void verifyInOrderHistoryTest(HashMap<String, String> input) throws IOException {
		// launchApplicationEcommerce();
		ProductPage productPage = landingPage.login(input.get("un"), input.get("pw"));
		OrderHistoryPageEcommerce orderHistoryPage = productPage.clickOnorderButton();
		Assert.assertTrue(orderHistoryPage.checkOrderedProduct(input.get("pro").toLowerCase()));
	}

	@DataProvider
	public Object[][] getData() throws IOException {
		//Ideal way to pass the data to the test is providde it as a hash map as below when we are dealing with the frameworks
		
//		HashMap<String, String> dataMap1 = new HashMap<String, String>();
//		dataMap1.put("un", "rahulshetty@gmail.com");
//		dataMap1.put("pw", "Iamking@000");
//		dataMap1.put("pro", "ZARA");
//		
//		HashMap<String, String> dataMap2 = new HashMap<String, String>();
//		dataMap2.put("un", "Udemyselenium@gmail.com");
//		dataMap2.put("pw", "Password1234");
//		dataMap2.put("pro", "ADIDAS");
		
		List<HashMap<String,String>> data = getJsonDataToHashMap(System.getProperty("user.dir") + "\\src\\test\\java\\eCommerce\\Data\\PurchaseOrder.Json");
		return new Object[][] {{data.get(0)},{data.get(1)}};
		
		//One way is to use like below (In below way we do not need to worry about indexing and is easy also)
		
		//return new Object[][]{{"rahulshetty@gmail.com","Iamking@000","ZARA"},{"Udemyselenium@gmail.com","Password1234","ADIDAS"}};		
		
		
		//Another Way is to define the test data separately making use of indexing like below 
		
//		Object ob[][] = new Object[2][3];
//		ob[0][0] = "rahulshetty@gmail.com";
//		ob[0][1] = "Iamking@000";
//		ob[0][2] = "ZARA";
//		ob[1][0] = "Udemyselenium@gmail.com";
//		ob[1][1] = "Password1234";
//		ob[1][2] = "ADIDAS";
	//	return ob;
	}

}
