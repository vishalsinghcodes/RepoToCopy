package eCommercePracticeOnly.StepDefinition;

import java.io.IOException;

import org.testng.Assert;

import eCommerce.PageObjects.CheckOutPage;
import eCommerce.PageObjects.ConfirmationPage;
import eCommerce.PageObjects.LandingPage;
import eCommerce.PageObjects.PaymentPage;
import eCommerce.PageObjects.ProductPage;
import eCommerce.TestComponents.BaseTest;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitionImplementation extends BaseTest {

	public LandingPage landingpage;
	public ProductPage productpage;
	public ConfirmationPage confirmationPage;

	@Given("I landed on Ecommerce landing page")
	public void I_landed_on_Ecommerce_landing_page() throws IOException { // you can give any name to method but people
																		// suggest to keep the same name as //
																			// statement
		landingpage = launchApplicationEcommerce();

	}

	@Given("^Loggedin with username (.+) and password (.+)$")
	public void Loggedin_with_username_and_password(String username, String password) {
		productpage = landingpage.login(username, password);

	}

	@When("^I add the product (.+) from Product catalogue Page into the cart$")
	public void I_add_the_product_from_Product_catalogue_Page_into_the_cart(String proname) {
		productpage.buyProduct(proname);

	}

	public CheckOutPage checkOutPage;

	@When("^Checkout (.+) in the cart and submit the order$")
	public void Checkout_in_the_cart_and_submit_the_order(String proname) {
		checkOutPage = productpage.clickOnCartButton();
		checkOutPage.verifyProduct(proname);
		PaymentPage paymentPage = checkOutPage.clickCheckoutButton();
		paymentPage.typeInCountryTextBox("Ind");
		paymentPage.SelectCountry("India");
		confirmationPage = paymentPage.clickPlaceOrderButton();

	}

	@Then("{string} message is displayed on the confirmation page and the browser is closed")
	public void message_is_displayed_on_the_confirmation_page(String str) {
		Assert.assertTrue(confirmationPage.verifyHeaderText(str));
		closebrowser();

	}

	@Then("{string} toast message is displayed and the browser is closed")
	public void toastMessageIsDisplayed(String expectedMessage) throws InterruptedException {	
		Assert.assertEquals(expectedMessage, landingPage.getErrorToastMessage());
		Thread.sleep(2000);
		closebrowser();
	}

}
