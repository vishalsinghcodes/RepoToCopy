package eCommerce.abtractComponent;


import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import eCommerce.PageObjects.CheckOutPage;
import eCommerce.PageObjects.OrderHistoryPageEcommerce;

public class AbstractClassReusables {
	WebDriver driver;

	@FindBy(xpath = "//button[@routerlink='/dashboard/cart']")
	WebElement cartButtonEle;
	
	@FindBy(xpath="//button[@routerlink='/dashboard/myorders']")
	WebElement myOrdersButton;

	public AbstractClassReusables(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void waitForElements(List<WebElement> proCardsEle) {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.visibilityOfAllElements(proCardsEle));
	}

	public void waitForElementToDisappear(WebElement ele) {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.invisibilityOf(ele));
	}

	public void waitForElement(WebElement ele) {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.visibilityOf(ele));
	}

	public CheckOutPage clickOnCartButton() {
		cartButtonEle.click();
		CheckOutPage checkOutPage = new CheckOutPage(driver);
		return checkOutPage;
	}
	
	public OrderHistoryPageEcommerce clickOnorderButton() {
		myOrdersButton.click();
		OrderHistoryPageEcommerce orderHistoryPage = new OrderHistoryPageEcommerce(driver);
		return orderHistoryPage;
	}

}
