package eCommerce.PageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import eCommerce.abtractComponent.AbstractClassReusables;

public class OrderHistoryPageEcommerce extends AbstractClassReusables{
	WebDriver driver;
	
	public OrderHistoryPageEcommerce(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//tr[@class='ng-star-inserted']/td[2]")
	List <WebElement> orderHistoryListEle;
	
	public boolean checkOrderedProduct(String str) {
		waitForElements(orderHistoryListEle);
		return orderHistoryListEle.stream().anyMatch(s->s.getText().contains(str));
		
	}
	
	
	

}
