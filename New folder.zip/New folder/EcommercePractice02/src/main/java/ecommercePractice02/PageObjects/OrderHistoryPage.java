package ecommercePractice02.PageObjects;

import java.util.List;
import java.util.stream.Collectors;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ecommercePractice02.AbstractClass.Reusables;

public class OrderHistoryPage extends Reusables{
	WebDriver driver;

	public OrderHistoryPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//tr[@class='ng-star-inserted']//td[2]")
	List<WebElement> orderHistoryList;
	
	public boolean checkOrderHistoryFor(String pro) {
		return orderHistoryList.stream().anyMatch(s->s.getText().contains(pro.toLowerCase()));
	}

	
	
	
	

}
