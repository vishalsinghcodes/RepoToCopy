package ecommercePractice02.PageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ecommercePractice02.AbstractClass.Reusables;

public class CartPage extends Reusables{
	WebDriver driver;

	public CartPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//button[text()='Checkout']")
	WebElement checkOutButtonEle;
	
	@FindBy(xpath="//div[@class='cartSection']//h3")
	List <WebElement> proListInCartEles; 

	public boolean checkProInCart(String proincart) {
		return proListInCartEles.stream().anyMatch(s->s.getText().toUpperCase().contains(proincart));
	}
	
	public CheckOutPage clickOnCheckOutButton() {
		checkOutButtonEle.click();
		CheckOutPage checkoutPage = new CheckOutPage(driver);
		return checkoutPage;
	}

	
	
	

}
