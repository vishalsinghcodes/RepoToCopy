package ecommercePractice02.PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ecommercePractice02.AbstractClass.Reusables;

public class LandingPage extends Reusables {
	WebDriver driver;

	public LandingPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[@role='alert']")
	WebElement loginErrorToastEle;
	
	@FindBy(id="userEmail")
	WebElement usernameTextBoxEle;
	
	@FindBy(id="userPassword")
	WebElement passwordTextBoxEle;
	
	@FindBy(id="login")
	WebElement loginButtonEle;
	
	

	public void gotoLandingPage() {
		driver.get("https://www.rahulshettyacademy.com/client/");	
	}
	
	public ProPage loginApplication(String un, String pw) {
		usernameTextBoxEle.sendKeys(un);
		passwordTextBoxEle.sendKeys(pw);
		loginButtonEle.click();	
		ProPage propage = new ProPage(driver);
		return propage;
		
	}
	
	public void validateLoginErrorToast() {
		waitForElementToBeVisibleOnPage(loginErrorToastEle);
		
	}
	
	
}
