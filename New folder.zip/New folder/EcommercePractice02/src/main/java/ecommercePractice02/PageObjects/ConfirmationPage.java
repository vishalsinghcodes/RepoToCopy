package ecommercePractice02.PageObjects;

import java.util.List;
import java.util.stream.Collectors;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ecommercePractice02.AbstractClass.Reusables;

public class ConfirmationPage extends Reusables{
	WebDriver driver;

	public ConfirmationPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="tr[class='ng-star-inserted'] td .ng-star-inserted")
	List<WebElement> orderNumbersEle;
	
	@FindBy(css=".hero-primary")
	WebElement headerText;
	
	public String getHeaderText() {
		return headerText.getText();
	}
	
	public List<String> getOrderNumbers() {
		List<String> orderNumbers = orderNumbersEle.stream().map(s->s.getText()).collect(Collectors.toList());
		return orderNumbers;
	}
	
	
	

}
