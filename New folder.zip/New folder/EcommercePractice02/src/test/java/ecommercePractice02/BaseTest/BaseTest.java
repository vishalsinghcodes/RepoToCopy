package ecommercePractice02.BaseTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.xml.crypto.Data;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLValidateContext;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import ecommercePractice02.PageObjects.LandingPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {
	public WebDriver driver;
	public LandingPage landingPage;

	public WebDriver initializeDriver() throws IOException {
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")
				+ "\\src\\main\\java\\ecommercePractice02\\resources\\GlobalProperties.properties");
		prop.load(fis);
		String browser = prop.getProperty("browser");

		switch (browser) {
		case "chrome":
			WebDriverManager.chromedriver().config();
			driver = new ChromeDriver();
			break;
		case "firefox":
			WebDriverManager.firefoxdriver().config();
			driver = new FirefoxDriver();
			break;
		case "edge":
			WebDriverManager.edgedriver().config();
			driver = new EdgeDriver();
			break;
		default:
			System.out.println("Browser not correct");
			break;
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		return driver;
	}

	@BeforeMethod(alwaysRun = true)
	public LandingPage launchApplication() throws IOException {
		driver = initializeDriver();
		landingPage = new LandingPage(driver);
		landingPage.gotoLandingPage();
		return landingPage;
	}

	@AfterMethod(alwaysRun = true)
	public void afterMethod() throws InterruptedException {
		Thread.sleep(2000);
		driver.close();
	}
	
	public String getScreenShotPath(WebDriver driver, String testname) throws IOException {
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\EcommercePractice02\\target"+testname+".png"));
		return System.getProperty("user.dir")+"\\EcommercePractice02\\target"+testname+".png";
	}

	public List<HashMap<String, String>> getdatafromjson(String pathToJson) throws IOException {
		String strfromJson = FileUtils.readFileToString(new File(pathToJson), StandardCharsets.UTF_8);
		ObjectMapper mapper = new ObjectMapper();
		List<HashMap<String,String>> data = mapper.readValue(strfromJson, new TypeReference<List<HashMap<String,String>>>() {
		}) ;
		return data;

	}

}
