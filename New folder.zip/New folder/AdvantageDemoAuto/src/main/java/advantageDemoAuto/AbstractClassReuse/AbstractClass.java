package advantageDemoAuto.AbstractClassReuse;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import advantageDemoAuto.PageObjects.*;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AbstractClass {
	WebDriver driver;
	@FindBy(xpath = "//li/a[text()='Bank Project']")
	WebElement BankProjectButtonEle;

	@FindBy(xpath = "//a")
	List<WebElement> allWebLinks;
	
	@FindBy(xpath="//li/a[text()='Log out']")
	WebElement logOutButtonEle;

	By WeblinksEles = By.xpath("//a");

	public AbstractClass(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void waitForElementtoappear(WebElement ele) {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.visibilityOf(ele));

	}

	public void waitForElementstoappear(List<WebElement> ele) {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.visibilityOfAllElements(ele));

	}

	public void checkallWebLinkUp(WebDriver driver) throws MalformedURLException, IOException, InterruptedException {
		List<WebElement> urlEleList = driver.findElements(WeblinksEles);
		SoftAssert sa = new SoftAssert();
		for (WebElement e : urlEleList) {
			HttpURLConnection conn = (HttpURLConnection) new URL(e.getAttribute("href")).openConnection();
			// System.out.println(e.getAttribute("href"));
			conn.setRequestMethod("HEAD");
			conn.connect();
			int responsecode = conn.getResponseCode();
			if (responsecode < 400)
				{System.out.println(e.getAttribute("href")+"is working");
				sa.assertTrue(true);}
			else
				System.out.println(e.getAttribute("href")+"is not working");
				sa.assertTrue(false, (e.getAttribute("href") + "----  with Text as ---  " + e.getText()
						+ "--------------------------  is not working"));
		}
		
		sa.assertAll();

	}

	public void skipPopups(WebDriver driver) throws InterruptedException {
//		WebElement frame1 = driver.findElement(By.id("google_ads_iframe_/24132379/INTERSTITIAL_DemoGuru99_0"));
//		driver.switchTo().frame(frame1);
//		WebElement frame2 = driver.findElement(By.id("ad_iframe"));
//		driver.switchTo().frame(frame2);
//		driver.findElement(By.xpath("//div[@id='dismiss-button']/div/span")).click();
//		driver.switchTo().defaultContent();

		if (driver.findElement(By.id("google_ads_iframe_/24132379/INTERSTITIAL_DemoGuru99_0")).isDisplayed()) {
			WebElement frame1 = driver.findElement(By.id("google_ads_iframe_/24132379/INTERSTITIAL_DemoGuru99_0"));
			driver.switchTo().frame(frame1);

			WebElement frame2 = driver.findElement(By.id("ad_iframe"));
			driver.switchTo().frame(frame2);
			try {driver.findElement(By.xpath("//div[@id='dismiss-button']/div/span")).isDisplayed() ;
				driver.findElement(By.xpath("//div[@id='dismiss-button']/div/span")).click();
				System.out.println("PopupAd found with close button below");
			} catch(Exception e) {
				driver.switchTo().defaultContent();
				driver.switchTo().frame(driver.findElement(By.id("google_ads_iframe_/24132379/INTERSTITIAL_DemoGuru99_0")));
				driver.findElement(By.xpath("//div[@class='toprow']//div[@id='dismiss-button']")).click();
				Thread.sleep(2000);
				System.out.println("PopupAd found with cross button on top");
			}
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
		}
	}

	public void saveNewUserIdAndPassword(String un, String pw) throws IOException {
		String path = System.getProperty("user.dir")
				+ "\\src\\main\\java\\advantageDemoAuto\\Resources\\NewUserCredentials.properties";
		Properties prop = new Properties();
		FileOutputStream fos = new FileOutputStream(path);
		prop.setProperty("username", un);
		prop.setProperty("password", pw);
		prop.store(fos, null);

	}

	public LandPage gotoBankLandingPagebyclickBankProjectbytton() {
		BankProjectButtonEle.click();
		LandPage landPage = new LandPage(driver);
		return landPage;
	}

	public String getTheUserNameFromPropFile() throws IOException {
		String path = System.getProperty("user.dir")
				+ "\\src\\main\\java\\advantageDemoAuto\\Resources\\NewUserCredentials.properties";
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(path);
		prop.load(fis);
		return prop.getProperty("username");
	}

	public String getThePasswordFromPropFile() throws IOException {
		String path = System.getProperty("user.dir")
				+ "\\src\\main\\java\\advantageDemoAuto\\Resources\\NewUserCredentials.properties";
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(path);
		prop.load(fis);
		return prop.getProperty("password");
	}

	public List<HashMap<String, String>> getnewCustomerData(String pathToCustData) throws IOException {
		String stringOfJson = FileUtils.readFileToString(
//				new File(System.getProperty("user.dir")
//						+ "\\src\\main\\java\\advantageDemoAuto\\Resources\\CreateNewUserData.Json"),
				new File(pathToCustData),
				StandardCharsets.UTF_8);
		ObjectMapper mapper = new ObjectMapper();
		List<HashMap<String, String>> data = mapper.readValue(stringOfJson,
				new TypeReference<List<HashMap<String, String>>>() {
				});
		return data;

	}

	public String string_Date_And_Time() {
		return new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	}
	
	public void logoutAccount(WebDriver driver) throws InterruptedException {
		logOutButtonEle.click();
		Thread.sleep(1000);
		driver.switchTo().alert().dismiss();;
		driver.close();
	}
	
	public boolean isPopUpAdVisible() {
		return driver.findElement(By.id("google_ads_iframe_/24132379/INTERSTITIAL_DemoGuru99_0")).isDisplayed();
	}
	
	public static void chromeUploadScript() throws IOException {
		
		Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\AutoITStuff\\Fileuploadscript.exe");
		
	}

}
