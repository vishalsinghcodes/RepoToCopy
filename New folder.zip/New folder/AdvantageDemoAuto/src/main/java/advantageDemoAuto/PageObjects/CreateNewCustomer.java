package advantageDemoAuto.PageObjects;

import advantageDemoAuto.AbstractClassReuse.AbstractClass;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import com.mysql.cj.protocol.Resultset;

public class CreateNewCustomer extends AbstractClass {
	public WebDriver driver;

	public CreateNewCustomer(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, "this");
	}

	@FindBy(xpath = "//input[@name='name']")
	WebElement customer_Name;

	@FindBy(xpath = "//label[@id='message']")
	WebElement customer_Name_validationTextEle;

	@FindBy(xpath = "//input[@name='rad1'][1]")
	WebElement maleRadioButtonEle;

	@FindBy(xpath = "//input[@name='rad1'][2]")
	WebElement femaleRadioButtonEle;

	@FindBy(css = "#dob")
	WebElement dobCalendarEle;

	@FindBy(xpath = "//textarea[@name='addr']")
	WebElement addressEle;

	@FindBy(xpath = "//input[@name='city']")
	WebElement cityEle;

	@FindBy(xpath = "//label[@id='message4']")
	WebElement cityEle_validationTextEle;

	// label[@id='message5']

	@FindBy(xpath = "//input[@name='state']")
	WebElement stateEle;

	@FindBy(xpath = "//label[@id='message5']")
	WebElement stateEle_validationTextEle;

	@FindBy(xpath = "//input[@name='pinno']")
	WebElement pinNumberEle;
	
	@FindBy(xpath = "//label[@id='message6']")
	WebElement pinNumberEle_validationTextEle;
	
	//label[@id='message6']

	@FindBy(xpath = "//input[@name='telephoneno']")
	WebElement phoneNumberEle;
	
	@FindBy(xpath = "//label[@id='message7']")
	WebElement phoneNumberEle_validationTextEle;

	@FindBy(xpath = "//input[@name='emailid']")
	WebElement eMailEle;
	
	@FindBy(xpath = "//label[@id='message9']")
	WebElement eMailEle_validationTextEle;
	

	public void fillNewCustomerForm() throws IOException {
		String pathToCustCreationData = System.getProperty("user.dir")
				+ "\\src\\main\\java\\advantageDemoAuto\\Resources\\CreateNewUserData.Json";
		List<HashMap<String, String>> data = getnewCustomerData(pathToCustCreationData);
		customer_Name.sendKeys(data.get(0).get("Customer_Name"));
		if (data.get(0).get("Gender").equalsIgnoreCase("male")) {
			maleRadioButtonEle.click();
		} else
			femaleRadioButtonEle.click();
		dobCalendarEle.sendKeys(data.get(0).get("Date_of_Birth"));
		addressEle.sendKeys(data.get(0).get("Address"));
		cityEle.sendKeys(data.get(0).get("City"));
		stateEle.sendKeys(data.get(0).get("State"));
		pinNumberEle.sendKeys(data.get(0).get("PIN"));
		phoneNumberEle.sendKeys(data.get(0).get("Telephone_Number"));
		eMailEle.sendKeys(data.get(0).get("E_mail"));
	}
	
	

	public void validateErrorMessagesOnCustomercreationForm(HashMap<String, String> data) throws IOException {
		SoftAssert as = new SoftAssert();
		customer_Name.sendKeys(data.get("Customer_Name"));
		waitForElementtoappear(customer_Name_validationTextEle);
		if (containsOnlyAlphabeticCharacters(data.get("Customer_Name"))) {
			as.assertTrue(true, "Correct Entry");
		} else {
			switch (whatoccursfirstfortextfield(data.get("Customer_Name"))) {
			case "number":
				as.assertEquals(customer_Name_validationTextEle.getText(), "Numbers are not allowed",
						"Numbers are not allowed");
				System.out.println("Numbers are not allowed in Customer_Name  -  " + data.get("Customer_Name"));
				break;
			case "special":
				as.assertEquals(customer_Name_validationTextEle.getText(), "Special characters are not allowed",
						"Special characters are not allowed");
				System.out.println(
						"Special characters are not allowed in Customer_Name  -  " + data.get("Customer_Name"));
				break;
			}
		}

		if (data.get("Gender").equalsIgnoreCase("male")) {
			maleRadioButtonEle.click();
		} else if (data.get("Gender").equalsIgnoreCase("female")) {
			femaleRadioButtonEle.click();
		} else
			as.assertFalse(true, "Invalid gender entry");

		dobCalendarEle.sendKeys(data.get("Date_of_Birth"));
		addressEle.sendKeys(data.get("Address"));

		cityEle.sendKeys(data.get("City"));
		if (containsOnlyAlphabeticCharacters(data.get("City"))) {
			as.assertTrue(true, "Correct Entry");
		} else {
			switch (whatoccursfirstfortextfield(data.get("City"))) {
			case "number":
				as.assertEquals(cityEle_validationTextEle.getText(), "Numbers are not allowed",
						"Numbers are not allowed");
				System.out.println("Numbers are not allowed in City  -  " + data.get("City"));
				break;
			case "special":
				as.assertEquals(cityEle_validationTextEle.getText(), "Special characters are not allowed",
						"Special characters are not allowed");
				System.out.println("Special characters are not allowed in City  -  " + data.get("City"));
				break;
			}
		}

		stateEle.sendKeys(data.get("State"));
		if (containsOnlyAlphabeticCharacters(data.get("State"))) {
			as.assertTrue(true, "Correct Entry");
		} else {
			switch (whatoccursfirstfortextfield(data.get("State"))) {
			case "number":
				as.assertEquals(stateEle_validationTextEle.getText(), "Numbers are not allowed",
						"Numbers are not allowed");
				System.out.println("Numbers are not allowed in State  -  " + data.get("State"));
				break;
			case "special":
				as.assertEquals(stateEle_validationTextEle.getText(), "Special characters are not allowed",
						"Special characters are not allowed");
				System.out.println("Special characters are not allowed in State  -  " + data.get("State"));
				break;
			}
		}

		pinNumberEle.sendKeys(data.get("PIN"));
		if (isValidSixDigitNumber(data.get("PIN"))) {
			as.assertTrue(true, "Correct Entry");
		} else {
			switch (whatoccursfirstfornumberfield(data.get("PIN"))) {
			case "Special":
				as.assertEquals(pinNumberEle_validationTextEle.getText(), "Special characters are not allowed",
						"Special characters are not allowed");
				System.out.println("Special characters are not allowed in pin  -  " + data.get("PIN"));
				break;
			case "character":
				as.assertEquals(pinNumberEle_validationTextEle.getText(), "Characters are not allowed",
						"Characters are not allowed");
				System.out.println("Characters are not allowed in pin  -  " + data.get("PIN"));
				break;
			case "number":
				as.assertEquals(pinNumberEle_validationTextEle.getText(), "PIN Code must have 6 Digits",
						"PIN Code must have 6 Digits");
				System.out.println("PIN Code must have 6 Digits  -  " + data.get("PIN"));
				break;
			}
		}

		phoneNumberEle.sendKeys(data.get("Telephone_Number"));
		if (isValidTenDigitNumber(data.get("Telephone_Number"))) {
			as.assertTrue(true, "Correct Entry");
		} else {
			switch (whatoccursfirstfornumberfield(data.get("Telephone_Number"))) {
			case "Special":
				as.assertEquals(phoneNumberEle_validationTextEle.getText(), "Special characters are not allowed",
						"Special characters are not allowed");
				System.out.println("Special characters are not allowed phone number  -  " + data.get("Telephone_Number"));
				break;
			case "character":
				as.assertEquals(phoneNumberEle_validationTextEle.getText(), "Characters are not allowed",
						"Characters are not allowed");
				System.out.println("Characters are not allowed in phone number   -  " + data.get("Telephone_Number"));
				break;
			case "number"://here no error message is shown based on length of entry so giving only warning not a validation
				System.out.println("Phone number must have exactly 10 Digits  -  " + data.get("Telephone_Number"));
				break;
			}
		}
		
		
		eMailEle.sendKeys(data.get("E_mail"));
		if(!isValidEmail(data.get("E_mail"))) {
			as.assertEquals(eMailEle_validationTextEle.getText(), "Email-ID is not valid");
			System.out.println("Email-ID is not valid  -  " + data.get("E_mail"));
		}

		as.assertAll();
	}
	
	public void validateErrorMessagesOnCustomercreationFormdataFromDatabase(ResultSet data) throws IOException, SQLException {
	    SoftAssert as = new SoftAssert();
	    customer_Name.sendKeys(data.getString("Customer_Name"));
	    waitForElementtoappear(customer_Name_validationTextEle);
	    if (containsOnlyAlphabeticCharacters(data.getString("Customer_Name"))) {
	        as.assertTrue(true, "Correct Entry");
	    } else {
	        switch (whatoccursfirstfortextfield(data.getString("Customer_Name"))) {
	            case "number":
	                as.assertEquals(customer_Name_validationTextEle.getText(), "Numbers are not allowed",
	                        "Numbers are not allowed");
	                System.out.println("Numbers are not allowed in Customer_Name  -  " + data.getString("Customer_Name"));
	                break;
	            case "special":
	                as.assertEquals(customer_Name_validationTextEle.getText(), "Special characters are not allowed",
	                        "Special characters are not allowed");
	                System.out.println("Special characters are not allowed in Customer_Name  -  " + data.getString("Customer_Name"));
	                break;
	        }
	    }

	    if (data.getString("Gender").equalsIgnoreCase("male")) {
	        maleRadioButtonEle.click();
	    } else if (data.getString("Gender").equalsIgnoreCase("female")) {
	        femaleRadioButtonEle.click();
	    } else {
	        as.assertFalse(true, "Invalid gender entry");
	    }

	    dobCalendarEle.sendKeys(data.getString("Date_of_Birth"));
	    addressEle.sendKeys(data.getString("Address"));

	    cityEle.sendKeys(data.getString("City"));
	    if (containsOnlyAlphabeticCharacters(data.getString("City"))) {
	        as.assertTrue(true, "Correct Entry");
	    } else {
	        switch (whatoccursfirstfortextfield(data.getString("City"))) {
	            case "number":
	                as.assertEquals(cityEle_validationTextEle.getText(), "Numbers are not allowed",
	                        "Numbers are not allowed");
	                System.out.println("Numbers are not allowed in City  -  " + data.getString("City"));
	                break;
	            case "special":
	                as.assertEquals(cityEle_validationTextEle.getText(), "Special characters are not allowed",
	                        "Special characters are not allowed");
	                System.out.println("Special characters are not allowed in City  -  " + data.getString("City"));
	                break;
	        }
	    }

	    stateEle.sendKeys(data.getString("State"));
	    if (containsOnlyAlphabeticCharacters(data.getString("State"))) {
	        as.assertTrue(true, "Correct Entry");
	    } else {
	        switch (whatoccursfirstfortextfield(data.getString("State"))) {
	            case "number":
	                as.assertEquals(stateEle_validationTextEle.getText(), "Numbers are not allowed",
	                        "Numbers are not allowed");
	                System.out.println("Numbers are not allowed in State  -  " + data.getString("State"));
	                break;
	            case "special":
	                as.assertEquals(stateEle_validationTextEle.getText(), "Special characters are not allowed",
	                        "Special characters are not allowed");
	                System.out.println("Special characters are not allowed in State  -  " + data.getString("State"));
	                break;
	        }
	    }

	    pinNumberEle.sendKeys(data.getString("PIN"));
	    if (isValidSixDigitNumber(data.getString("PIN"))) {
	        as.assertTrue(true, "Correct Entry");
	    } else {
	        switch (whatoccursfirstfornumberfield(data.getString("PIN"))) {
	            case "Special":
	                as.assertEquals(pinNumberEle_validationTextEle.getText(), "Special characters are not allowed",
	                        "Special characters are not allowed");
	                System.out.println("Special characters are not allowed in pin  -  " + data.getString("PIN"));
	                break;
	            case "character":
	                as.assertEquals(pinNumberEle_validationTextEle.getText(), "Characters are not allowed",
	                        "Characters are not allowed");
	                System.out.println("Characters are not allowed in pin  -  " + data.getString("PIN"));
	                break;
	            case "number":
	                as.assertEquals(pinNumberEle_validationTextEle.getText(), "PIN Code must have 6 Digits",
	                        "PIN Code must have 6 Digits");
	                System.out.println("PIN Code must have 6 Digits  -  " + data.getString("PIN"));
	                break;
	        }
	    }

	    phoneNumberEle.sendKeys(data.getString("Telephone_Number"));
	    if (isValidTenDigitNumber(data.getString("Telephone_Number"))) {
	        as.assertTrue(true, "Correct Entry");
	    } else {
	        switch (whatoccursfirstfornumberfield(data.getString("Telephone_Number"))) {
	            case "Special":
	                as.assertEquals(phoneNumberEle_validationTextEle.getText(), "Special characters are not allowed",
	                        "Special characters are not allowed");
	                System.out.println("Special characters are not allowed phone number  -  " + data.getString("Telephone_Number"));
	                break;
	            case "character":
	                as.assertEquals(phoneNumberEle_validationTextEle.getText(), "Characters are not allowed",
	                        "Characters are not allowed");
	                System.out.println("Characters are not allowed in phone number   -  " + data.getString("Telephone_Number"));
	                break;
	            case "number":
	                System.out.println("Phone number must have exactly 10 Digits  -  " + data.getString("Telephone_Number"));
	                break;
	        }
	    }

	    eMailEle.sendKeys(data.getString("E_mail"));
	    if (!isValidEmail(data.getString("E_mail"))) {
	        as.assertEquals(eMailEle_validationTextEle.getText(), "Email-ID is not valid");
	        System.out.println("Email-ID is not valid  -  " + data.getString("E_mail"));
	    }

	    as.assertAll();
	}


	public static String whatoccursfirstfortextfield(String input) {
		for (char c : input.toCharArray()) {
			if (Character.isDigit(c) || Character.isWhitespace(c)) {
				return "number";
			} else if (!Character.isLetterOrDigit(c)) {
				return "special";
			}
		}
		return null;
	}
	
	public static String whatoccursfirstfornumberfield(String input) {
		boolean hasSpecialCharacter = false;
        boolean hasLetterOrWhitespace = false;
        boolean hasOnlyNumbers = true;

        for (char c : input.toCharArray()) {
            if (!Character.isLetterOrDigit(c) && !Character.isWhitespace(c)) {
                hasSpecialCharacter = true;
                hasOnlyNumbers = false;
            }

            if (Character.isLetter(c) || Character.isWhitespace(c)) {
                hasLetterOrWhitespace = true;
                hasOnlyNumbers = false;
            }
            
            if (!Character.isDigit(c)) {
                hasOnlyNumbers = false;
            }
        }

        if (hasSpecialCharacter) {
            return "Special";
        } else if (hasOnlyNumbers) {
            return "number";
        } else if (hasLetterOrWhitespace) {
            return "character";
        } else {
            return "Unknown";
        }
	}
	
	

	public static boolean isNotANumber(String input) {
		for (char c : input.toCharArray()) {
			if (!Character.isDigit(c) || Character.isWhitespace(c)) {
				return true;
			}
		}
		return false;
	}

	public static boolean containsSpecialCharacter(String input) {
		for (char c : input.toCharArray()) {
			if (!Character.isLetterOrDigit(c)) {
				return true;
			}
		}
		return false;
	}

	public static boolean containsOnlyAlphabeticCharacters(String input) {
		for (char c : input.toCharArray()) {
			if (!Character.isLetter(c)) {
				return false;
			}
		}
		return true;
	}

	public static boolean isValidSixDigitNumber(String input) {
		if (input.length() != 6) {
			return false;
		}
		for (char c : input.toCharArray()) {
			if (!Character.isDigit(c)) {
				return false;
			}
		}
		return true;
	}
	public static boolean isValidTenDigitNumber(String input) {
		if (input.length() != 10) {
			return false;
		}
		for (char c : input.toCharArray()) {
			if (!Character.isDigit(c)) {
				return false;
			}
		}
		return true;
	}
	
	 public static boolean isValidEmail(String input) {
	        // Check if the input contains "@" and ".com"
	        if (!input.contains("@") || !input.contains(".com")) {
	            return false;
	        }

	        // Get the position of "@" and ".com"
	        int atIndex = input.indexOf("@");
	        int comIndex = input.indexOf(".com");

	        // Check if there's at least one character before "@" and ".com"
	        if (atIndex <= 0 || comIndex <= 0 || atIndex >= comIndex - 1) {
	            return false;
	        }

	        return true;
	    }

}
