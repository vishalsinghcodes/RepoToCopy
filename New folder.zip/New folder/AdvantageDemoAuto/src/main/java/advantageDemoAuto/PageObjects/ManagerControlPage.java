package advantageDemoAuto.PageObjects;
import org.testng.asserts.Assertion;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.stream.Collectors;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import advantageDemoAuto.AbstractClassReuse.AbstractClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ManagerControlPage extends AbstractClass {
	public WebDriver driver;

	public ManagerControlPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, "this");
	}
	
	@FindBy(css = ".heading3")
	WebElement flowingText;
	
	@FindBy(xpath="//li/a[text()='New Customer']")
	WebElement newCustButtonEle;
	
	@FindBy(xpath="//li/a[text()='Log out']")
	WebElement logOutButtonEle;
	
	public boolean checkFlowingText(String str) {
		return flowingText.getText().equalsIgnoreCase(str);
	}

	public CreateNewCustomer createNewUserbuttonClick() {
		newCustButtonEle.click();
		//skipPopups(driver);
		CreateNewCustomer createNewCustomer = new CreateNewCustomer(driver);
		return createNewCustomer;	
	}
	
	public void logoutAccount() throws InterruptedException {
		logOutButtonEle.click();
		Thread.sleep(1000);
		driver.switchTo().alert().dismiss();
	}
	
	
	
	

}
