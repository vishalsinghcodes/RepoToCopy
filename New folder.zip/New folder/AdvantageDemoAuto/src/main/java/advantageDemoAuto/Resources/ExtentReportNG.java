package advantageDemoAuto.Resources;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;


public class ExtentReportNG  {
	
	
	public static ExtentReports returnreport()   {
		
		ExtentSparkReporter reporter = new ExtentSparkReporter(System.getProperty("user.dir") + "\\ExtentReports\\Reports_"+string_Date_And_Time()+".html");
		reporter.config().setDocumentTitle("Automation Test Result");
		reporter.config().setReportName("Bank Test Results");

		ExtentReports extent = new ExtentReports();
		String Tester = System.getProperty("Tester") != null ? System.getProperty("Tester")
				: "TriggeredByVishalLocalPC";
		extent.setSystemInfo("Tester", Tester);
		extent.attachReporter(reporter);

		
		return extent;
	}
	
	public static String string_Date_And_Time() {
		return new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	}

}
