package advantageDemoAuto.TestCases;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import advantageDemoAuto.AbstractClassReuse.AbstractClass;
import advantageDemoAuto.PageObjects.CreateNewCustomer;
import advantageDemoAuto.PageObjects.LandPage;
import advantageDemoAuto.PageObjects.ManagerControlPage;
import advantageDemoAuto.TestComponents.BaseTest;
import advantageDemoAuto.TestComponents.RetryClass;

public class CreateNewCustomerTestCases extends BaseTest{
	
	@Test
	public void createNewUserForFillTestandSubmit() throws  InterruptedException, IOException {
		LandPage landingPage = launchApplication();
		ManagerControlPage managerControlPage = landingPage.loginWithIdPw(landingPage.getTheUserNameFromPropFile(), landingPage.getThePasswordFromPropFile());
		managerControlPage.skipPopups(driver);
		CreateNewCustomer createNewCustomer = managerControlPage.createNewUserbuttonClick();
		createNewCustomer.skipPopups(driver);
		createNewCustomer.fillNewCustomerForm();
		//createNewCustomer.logoutAccount(driver);
	}
	
	@Test(groups = "Connection_Status_Check")
	public void checkAllLinksonCustomerCreationPage() throws IOException, InterruptedException{
		LandPage landingPage = launchApplication();
		ManagerControlPage managerControlPage = landingPage.loginWithIdPw(landingPage.getTheUserNameFromPropFile(), landingPage.getThePasswordFromPropFile());
		managerControlPage.skipPopups(driver);
		CreateNewCustomer createNewCustomer = managerControlPage.createNewUserbuttonClick();
		managerControlPage.skipPopups(driver);
		createNewCustomer.checkallWebLinkUp(driver);
		createNewCustomer.logoutAccount(driver);
	}
	
	@Test(groups="googleAdscheck",retryAnalyzer = RetryClass.class)//
	public void checkPopupOnClickingCreateCustomerTest() throws IOException {
		LandPage landingPage = launchApplication();
		ManagerControlPage managerControlPage = landingPage.loginWithIdPw(landingPage.getTheUserNameFromPropFile(), landingPage.getThePasswordFromPropFile());
		CreateNewCustomer createNewCustomer = managerControlPage.createNewUserbuttonClick();
		Assert.assertTrue(createNewCustomer.isPopUpAdVisible());
	}
	
	@Test(dataProvider = "datapro")
	public void validatetextinCustomercreationForm(HashMap<String,String> getdata) throws IOException, InterruptedException {
		LandPage landingPage = launchApplication();
		ManagerControlPage managerControlPage = landingPage.loginWithIdPw(landingPage.getTheUserNameFromPropFile(), landingPage.getThePasswordFromPropFile());
		CreateNewCustomer createNewCustomer = managerControlPage.createNewUserbuttonClick();
		createNewCustomer.skipPopups(driver);
		createNewCustomer.validateErrorMessagesOnCustomercreationForm(getdata);	
	}
	
	@Test(groups = "databasedataset", enabled=false)
	public void validateErrorMessagesOnCustomercreationFormdataFromDatabaseTest() throws IOException, InterruptedException, SQLException {
		ResultSet getdata = getDataFromDBforcustomercreation();
		while(getdata.next()) {
		LandPage landingPage = launchApplication();
		ManagerControlPage managerControlPage = landingPage.loginWithIdPw(landingPage.getTheUserNameFromPropFile(), landingPage.getThePasswordFromPropFile());
		CreateNewCustomer createNewCustomer = managerControlPage.createNewUserbuttonClick();
		createNewCustomer.skipPopups(driver);
		createNewCustomer.validateErrorMessagesOnCustomercreationFormdataFromDatabase(getdata);	
		//driver.close();
		}
	}
	

	@DataProvider
	public Object[] datapro() throws IOException{
		String pathtocustomercreationdata = System.getProperty("user.dir")+"\\src\\test\\java\\advantageDemoAuto\\TestData\\TestDataforcustomerForm.json";
		AbstractClass ab = new AbstractClass(driver);
		List<HashMap<String,String>> data =  ab.getnewCustomerData(pathtocustomercreationdata);
		int noOfrecordsToTest = data.size();
		Object datatoTest[] = new Object[noOfrecordsToTest];
		for(int i=0;i<noOfrecordsToTest;i++) {
			datatoTest[i] = data.get(i);
		}
		
			//return new Object[][] {{data.get(0)},{data.get(1)}};
		return datatoTest;
	}
	
	
	
	
	

}
