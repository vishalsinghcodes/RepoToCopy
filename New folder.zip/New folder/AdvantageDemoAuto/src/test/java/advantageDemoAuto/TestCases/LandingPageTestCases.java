package advantageDemoAuto.TestCases;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import advantageDemoAuto.AbstractClassReuse.AbstractClass;
import advantageDemoAuto.PageObjects.LandPage;
import advantageDemoAuto.PageObjects.NewTestUserCreationPage;
import advantageDemoAuto.PageObjects.NewUserDetailsPage;
import advantageDemoAuto.TestComponents.BaseTest;

public class LandingPageTestCases extends BaseTest {

	@Test
	public void landOnLandingPageTest() throws IOException {
		LandPage lp = launchApplication();
		Assert.assertEquals(driver.getCurrentUrl(), "https://demo.guru99.com/V1/index.php");
		lp.LandPageTitlecheck();
	}

	@Test(groups = "Connection_Status_Check")
	public void checkWebLinksWorkingOnLandPageTest() throws IOException, InterruptedException {
		LandPage lp = launchApplication();
		lp.checkallWebLinkUp(driver);
	}

	@Test
	public void NewTestUserCreationPageCenterTextTest() throws IOException, InterruptedException {
		LandPage lp = launchApplication();
		NewTestUserCreationPage newTestUserCreationPage = lp.clickOnlinkToCreateNewCredentialsEle();
		Thread.sleep(2000);
		newTestUserCreationPage.skipPopups(driver);
		Assert.assertTrue(newTestUserCreationPage.getCenterText().contains("Enter your email address to get"));
	}

	@Test
	public void createNewUserTest() throws IOException, InterruptedException {
		LandPage lp = launchApplication();
		NewTestUserCreationPage newTestUserCreationPage = lp.clickOnlinkToCreateNewCredentialsEle();
		Thread.sleep(2000);
		if (driver.findElements(By.tagName("iframe")) != null) {
			newTestUserCreationPage.skipPopups(driver);
		}
		NewUserDetailsPage newUserDetailsPage = newTestUserCreationPage.newUserCreationApplication("mno@gmail.com");
		newUserDetailsPage.saveNewUserDetailsinPropertyFile(newUserDetailsPage.getnewUserID(),
				newUserDetailsPage.getnewUserPassword());
		Assert.assertTrue(driver.getCurrentUrl().contains("https://demo.guru99.com/access.php?uid"));
		System.out.println("Your User Id is : " + newUserDetailsPage.getnewUserID());
		System.out.println("Your User Password is : " + newUserDetailsPage.getnewUserPassword());
		// driver.close();
	}

	@Test(groups = "googleAdscheck")
	public void checkAdonClickingHereTextTest() throws IOException, InterruptedException {
		LandPage lp = launchApplication();
		NewTestUserCreationPage newTestUserCreationPage = lp.clickOnlinkToCreateNewCredentialsEle();
		Thread.sleep(1000);
		Assert.assertTrue(newTestUserCreationPage.isPopUpAdVisible());
	}

	@Test(groups = "negativeTestCase")
	public void wrongUserIdPwpopupCheck() throws IOException {
		LandPage lp = launchApplication();
		Assert.assertTrue(lp.checkInvalidUserPopUpAndText("wrongusername", "wrongpassword"));

	}

	@Test(groups = "negativeTestCase")
	public void UserIdPwrequiredTextValidation() throws IOException {
		LandPage lp = launchApplication();
		Assert.assertEquals(lp.requiredFieldBlankMessageUserID(), "User-ID must not be blank");
		Assert.assertEquals(lp.requiredFieldBlankMessagePassword(), "Password must not be blank");

	}

	@Test(groups="uploadDownloadValidation")
	public void testUploadAndDownloadFile() throws IOException, InterruptedException { // File successfully updloaded and downloaded and deleted 
		String downloadPath = System.getProperty("user.dir") + "\\AutoITStuff";		
		LandPage lp = launchApplication();
		driver.get("https://altoconvertpdftojpg.com/");
		driver.findElement(By.id("browse")).click();
		Thread.sleep(3000);
		AbstractClass.chromeUploadScript();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#submit_btn")).click();
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(10));
		w.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Download")));
		driver.findElement(By.linkText("Download")).click();
		Thread.sleep(5000);
		//driver.close();
		File f = new File(downloadPath + "\\PDFtoupload.jpg");
		if (f.exists()) {
			System.out.println("File exists");
			f.delete();
		}
		if (!f.exists()) {
		System.out.println("File deleted successfully");
		}

	}

}
