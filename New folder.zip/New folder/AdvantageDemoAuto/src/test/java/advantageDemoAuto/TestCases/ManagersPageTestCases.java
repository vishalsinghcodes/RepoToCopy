package advantageDemoAuto.TestCases;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import advantageDemoAuto.PageObjects.LandPage;
import advantageDemoAuto.AbstractClassReuse.AbstractClass;

import advantageDemoAuto.PageObjects.ManagerControlPage;
import advantageDemoAuto.TestComponents.BaseTest;

public class ManagersPageTestCases extends BaseTest {

	@Test
	public void checkManagerableTologin() throws IOException, InterruptedException {
		LandPage landingPage = launchApplication();
		ManagerControlPage managerControlPage = landingPage.loginWithIdPw(landingPage.getTheUserNameFromPropFile(),
				landingPage.getThePasswordFromPropFile());
		Thread.sleep(2000);
		Assert.assertTrue(driver.getCurrentUrl().contains("https://demo.guru99.com/V1/html/Managerhomepage.php"));
	}

	@Test(groups = "Connection_Status_Check")
	public void checkManagerloginWebLinksWorkingTest() throws IOException, InterruptedException {
		LandPage landingPage = launchApplication();
		ManagerControlPage managerControlPage = landingPage.loginWithIdPw(landingPage.getTheUserNameFromPropFile(),
				landingPage.getThePasswordFromPropFile());
		managerControlPage.checkallWebLinkUp(driver);
	}

	@Test
	public void checkMarqeeTextTest() throws IOException {
		LandPage landingPage = launchApplication();
		ManagerControlPage managerControlPage = landingPage.loginWithIdPw(landingPage.getTheUserNameFromPropFile(),
				landingPage.getThePasswordFromPropFile());
		Assert.assertTrue(managerControlPage.checkFlowingText("Welcome To Manager's Page of GTPL Bank"));
	}

	@Test
	public void managerAbletoLogoutTest() throws IOException, InterruptedException {
		LandPage landingPage = launchApplication();
		ManagerControlPage managerControlPage = landingPage.loginWithIdPw(landingPage.getTheUserNameFromPropFile(),
				landingPage.getThePasswordFromPropFile());
		managerControlPage.logoutAccount();
	}

	@Test(groups = "databasedataset", enabled = false) // Here It will be reported as a single test . .I have disables it as it was fetching data and running test in one go
	// Please refer to below test. 
	public void checkManagerableTologinwithDatafromDatabase() throws IOException, InterruptedException, SQLException {
		ResultSet rs = getDataFromDBforuserLogin();
		SoftAssert as = new SoftAssert();
		while (rs.next()) {
			LandPage landingPage = launchApplication();
			ManagerControlPage managerControlPage = landingPage.loginWithIdPw(rs.getString("username"),
					rs.getString("password"));
			try {
				driver.switchTo().alert().getText().equalsIgnoreCase("User is not valid");
				as.assertTrue(false, "User is not valid, Popup handeled");
				System.out.println(rs.getString("username") + "   " + rs.getString("password"));
				driver.switchTo().alert().accept();

			} catch (Exception e) {
				as.assertTrue(driver.getCurrentUrl().contains("https://demo.guru99.com/V1/html/Managerhomepage.php"));

			}
			driver.close();
		}
		as.assertAll();
	}
	
	@Test(dataProvider = "getdatausercredentials", groups = "databasedataset") // Here It will be reported as separate tests based on the number of records found in table
	public void checkManagerableTologinwithDatafromDatabasebutWithDataProvider(String user, String pass) throws IOException, InterruptedException, SQLException {
		SoftAssert as = new SoftAssert();
			LandPage landingPage = launchApplication();
			landingPage.loginWithIdPw(user,	pass);
			try {
				driver.switchTo().alert().getText().equalsIgnoreCase("User is not valid");
				as.assertTrue(true, "User is not valid, Popup handeled");
				System.out.println(user + "   " + pass + " is wrong and Popup appeared");
				driver.switchTo().alert().accept();

			} catch (Exception e) {
				as.assertTrue(driver.getCurrentUrl().contains("https://demo.guru99.com/V1/html/Managerhomepage.php"));
			}

		as.assertAll();
	}
	
	@DataProvider
	public Object[][] getdatausercredentials() throws SQLException {
		int numberOfRows = getnumberofRowsDBforuserLogin();
		int numberOfcols = 2;
		ResultSet rs = getDataFromDBforuserLogin();
		//Object[][] data = new Object[numberOfRows][numberOfcols];
		Object[][] data = new Object[numberOfRows][2];
		for(int i=0;i<numberOfRows;i++) {
			rs.next();
			for(int j = 0;j<numberOfcols;j++) {
//				data[i][0]=rs.getString("username");
//				data[i][1]=rs.getString("password");	
				data[i][j]=rs.getNString(j+1);
			}
		}
		return data;
		
	}
	

}
