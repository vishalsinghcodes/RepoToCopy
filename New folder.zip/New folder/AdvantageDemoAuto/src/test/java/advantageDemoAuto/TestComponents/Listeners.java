package advantageDemoAuto.TestComponents;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import advantageDemoAuto.Resources.ExtentReportNG;

public class Listeners extends BaseTest implements ITestListener {

	WebDriver driver;
	ExtentReports extent = ExtentReportNG.returnreport();
	ExtentTest test;
	ThreadLocal<ExtentTest> safetest = new ThreadLocal<ExtentTest>();
	String screenshotPath = null;
	@Override
	public void onTestStart(ITestResult result) {
		test = extent.createTest(result.getMethod().getMethodName());
		safetest.set(test);
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		safetest.get().log(Status.PASS, result.getMethod().getMethodName() + " is passed");
		//safetest.get().log(Status.PASS, result.getThrowable());

		try {
			driver = (WebDriver) result.getTestClass().getRealClass().getField("driver").get(result.getInstance());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			screenshotPath = getscreenshotPath(driver, result.getMethod().getMethodName());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		safetest.get().addScreenCaptureFromPath(screenshotPath, result.getMethod().getMethodName());
	}

	@Override
	public void onTestFailure(ITestResult result) {
		safetest.get().log(Status.FAIL, result.getMethod().getMethodName() + " is Failed");
		safetest.get().log(Status.FAIL, result.getThrowable());
		screenshotPath = null;

		try {
			driver = (WebDriver) result.getTestClass().getRealClass().getField("driver").get(result.getInstance());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			screenshotPath = getscreenshotPath(driver, result.getMethod().getMethodName());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		safetest.get().addScreenCaptureFromPath(screenshotPath, result.getMethod().getMethodName());

	}

	@Override
	public void onTestSkipped(ITestResult result) {
		safetest.get().log(Status.SKIP, result.getMethod().getMethodName() + " is Skipped");
		safetest.get().log(Status.SKIP, result.getThrowable());
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// not implemented
	}

	@Override
	public void onTestFailedWithTimeout(ITestResult result) {
		onTestFailure(result);
	}

	@Override
	public void onStart(ITestContext context) {
		// not implemented
	}

	@Override
	public void onFinish(ITestContext context) {

		extent.flush();
		// driver.close();
	}

}
