package advantageDemoAuto.TestComponents;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import advantageDemoAuto.PageObjects.LandPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {

	public WebDriver driver;
	LandPage landPage;
	private static ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();

	public WebDriver initializeDriver() throws IOException {
		String pathToPropertyFile = System.getProperty("user.dir")
				+ "\\src\\main\\java\\advantageDemoAuto\\Resources\\GlobalProperties.properties";
		FileInputStream fis = new FileInputStream(pathToPropertyFile);
		Properties prop = new Properties();
		prop.load(fis);
		String browser = System.getProperty("browser") != null ? System.getProperty("browser")
				: prop.getProperty("browser");
		String headoption = System.getProperty("headoption") != null ? System.getProperty("headoption")
				: prop.getProperty("headoption");
		// String tester = prop.getProperty("tester");

		switch (browser) {
		case "chrome":
			String downloadPath = System.getProperty("user.dir") + "\\AutoITStuff";
			ChromeOptions cop = new ChromeOptions();
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("profile.default_content_settings.popups", 0);
			chromePrefs.put("download.default_directory", downloadPath);
			cop.setExperimentalOption("prefs", chromePrefs);
			cop.addArguments(headoption, "--disable -notifications");
			cop.setAcceptInsecureCerts(true);
			WebDriverManager.chromedriver().config();
			driver = new ChromeDriver(cop);
			
			break;
		case "firefox":
			FirefoxOptions fop = new FirefoxOptions();
			fop.addArguments(headoption, "--disable -notifications");
			fop.setAcceptInsecureCerts(true);
			WebDriverManager.firefoxdriver().config();
			driver = new FirefoxDriver(fop);
			
			break;
		case "edge":
			EdgeOptions eop = new EdgeOptions();
			eop.addArguments(headoption, "--disable -notifications");
			eop.setAcceptInsecureCerts(true);
			WebDriverManager.edgedriver().config();
			driver = new EdgeDriver(eop);
			
			break;
		default:
			System.out.println("NO SUCH BROWSER AVAILABLE");
			break;
		}

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		// driver.manage().addCookie(new
		// Cookie("_ga","GA1.2.603221194.1668917591","/"));
		// driver.manage().window().setSize(new Dimension(1440, 900));
		//driverThreadLocal.set(driver);
		//return driverThreadLocal.get();
		return driver;
	}

	public LandPage launchApplication() throws IOException {
		driver = initializeDriver();
		landPage = new LandPage(driver);
		landPage.gotoLandingPage();
		return landPage;
	}

	public String getscreenshotPath(WebDriver driver, String testName) throws IOException {
		String screenshotPath = System.getProperty("user.dir") + "\\ScreenShots\\" + testName + string_Date_And_Time()
				+ ".png";
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File(screenshotPath));
		return screenshotPath;
	}

	@AfterMethod(alwaysRun = true)
	public void closeDriver() {
	
		driver.close();
		

	}

	public String string_Date_And_Time() {
		return new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	}

	public ResultSet getDataFromDBforuserLogin() throws SQLException {
		String host = "localhost";
		String port = "3306";
		Connection dbconn = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/demoprojectqadb",
				"root", "Nokia@4230");
		Statement statement = dbconn.createStatement();
		ResultSet rs = statement.executeQuery("Select * from usercredentials");
		return rs;
	}
	
	public int getnumberofRowsDBforuserLogin() throws SQLException {
		String host = "localhost";
		String port = "3306";
		Connection dbconn = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/demoprojectqadb",
				"root", "Nokia@4230");
		Statement statement = dbconn.createStatement();
		ResultSet rs = statement.executeQuery("Select Count(*) AS countrow from usercredentials;");
		rs.next();
		String numberofRows = rs.getString("countrow");
		return Integer.parseInt(numberofRows);
	}

	
	public ResultSet getDataFromDBforcustomercreation() throws SQLException {
		String host = "localhost";
		String port = "3306";
		Connection dbconn = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/demoprojectqadb",
				"root", "Nokia@4230");
		Statement statement = dbconn.createStatement();
		ResultSet rs = statement.executeQuery("Select * from customercreationdata");
		return rs;
	}
	
	

}
