import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class FlightbookingDropdown {

	public static void main(String args[]) throws InterruptedException {

		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
		driver.manage().window().maximize();

		// for country selection dropdown

		WebElement ele = driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"));
		Select condrp = new Select(ele);
		Thread.sleep(2000);
		condrp.selectByIndex(2);
		System.out.println(condrp.getFirstSelectedOption().getText());
		Thread.sleep(2000);
		condrp.selectByValue("USD");
		System.out.println(condrp.getFirstSelectedOption().getText());
		Thread.sleep(2000);
		condrp.selectByVisibleText("AED");
		System.out.println(condrp.getFirstSelectedOption().getText());
		Thread.sleep(1000);

		// for pessegers selection dropdown
		int noOfadults = 4;
		int noOfChilds = 2;
		int noOfInfants = 1;

		driver.findElement(By.className("paxinfo")).click();
		Thread.sleep(1000);
		// to add adults
		for (int i = 1; i < noOfadults; i++) {
			driver.findElement(By.id("hrefIncAdt")).click();
		}
		// to add childs
		for (int i = 1; i <= noOfChilds; i++) {
			driver.findElement(By.id("hrefIncChd")).click();
		}
		// to add infants
		for (int i = 1; i <= noOfInfants; i++) {
			driver.findElement(By.id("hrefIncInf")).click();
		}
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("input[value='Done']")).click();
		String pasfinal = driver.findElement(By.id("divpaxinfo")).getText();
		System.out.println(pasfinal);
		Assert.assertEquals(pasfinal, noOfadults + " Adult, " + noOfChilds + " Child, " + noOfInfants + " Infant");
		System.out.println(noOfadults + " Adult, " + noOfChilds + " Child, " + noOfInfants + " Infant");
		
		//Dynamic Dropdown (dropdown based o some action) From to City selection 
		driver.findElement(By.cssSelector("#ctl00_mainContent_ddl_originStation1_CTXT")).click();
		driver.findElement(By.xpath("//a[@value='DEL']")).click();
		Thread.sleep(1);
		//driver.findElement(By.xpath("(//a[@value='IXJ'])[2]")).click(); // Dynamic dropdown with indexes. maybe they will not approve index so lets see it 
		driver.findElement(By.xpath("//div[@id='glsctl00_mainContent_ddl_destinationStation1_CTNR']/table/tbody//div[@class='dropdownDiv']//a[@value='IXJ']")).click();
		Thread.sleep(1);
		
		//Handling Calendar
		//first for one way trip(Return date  will not be there) 
		driver.findElement(By.cssSelector("a[class*='highlight']")).click();
		
		//test to check that return date is disabled when one way is selected 
		if(driver.findElement(By.id("ctl00_mainContent_rbtnl_Trip_0")).isSelected()) {
			String check = driver.findElement(By.xpath("//*[@id='ctl00_mainContent_view_date2']/parent::div")).getAttribute("style");	
			System.out.println(check);
			if(check.contains("opacity: 0.5;"))
			System.out.println("Return date is disabed");
		}
		
		
		//Auto suggestive dropdown (options in dropdown based on text entered 
		driver.findElement(By.id("autosuggest")).sendKeys("IND");
		Thread.sleep(3);
		List<WebElement> listauto= new ArrayList<WebElement>();
		listauto = driver.findElements(By.cssSelector("li.ui-menu-item a"));
		
		for(WebElement el : listauto) {
			System.out.println(el.getText());
		}
		
		for(WebElement el : listauto) {
			if(el.getText().equalsIgnoreCase("india")) {
				el.click();
				break;
			}
		}
		
		//checkox test, radio buttons
		driver.findElement(By.id("ctl00_mainContent_chk_friendsandfamily")).click();
		driver.findElement(By.id("ctl00_mainContent_chk_SeniorCitizenDiscount")).click();
		System.out.println(driver.findElement(By.id("ctl00_mainContent_chk_SeniorCitizenDiscount")).isSelected());
		Assert.assertTrue(driver.findElement(By.id("ctl00_mainContent_chk_SeniorCitizenDiscount")).isSelected());
		int noOfCheckBox = driver.findElements(By.xpath("//input[@type='checkbox']")).size();  // no of checkboxes
		System.out.println(noOfCheckBox);
		Assert.assertFalse(noOfCheckBox==4);
		
		
		driver.findElement(By.name("ctl00$mainContent$btn_FindFlights")).click();
		
		
		
		Thread.sleep(3);
		
		
		
		//driver.close();

	}

}
