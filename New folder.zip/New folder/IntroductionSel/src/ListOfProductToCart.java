import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ListOfProductToCart {

	public static void main(String[] args) throws InterruptedException {
		String[] proNeeded = { "Cauliflower", "Pumpkin", "Banana", "Mango","Capsicum"};
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
		// //button[contains(text(),'ADD TO CART')]
		Thread.sleep(3000);
		int j = 0;
		List<WebElement> proList = new ArrayList<WebElement>();
		proList = driver.findElements(By.cssSelector("h4.product-name"));
		List l1 = Arrays.asList(proNeeded);
		for (int i = 0; i < proList.size(); i++) {
			String proName = proList.get(i).getText();
			proName = proName.split("-")[0].trim();

			if (l1.contains(proName)) {
				j++;
				System.out.println(proName);
				System.out.println(i);
				driver.findElements(By.xpath("//a[@class='increment']")).get(i).click();
				//driver.findElement(By.xpath("(//button[contains(text(),'ADD TO CART')])[" + (i) + "]")).click();
				//driver.findElements(By.xpath("//button[contains(text(),'ADD TO CART')]")).get(i).click();
				driver.findElements(By.cssSelector("div.product button[type='button']")).get(i).click();
				if(j==proNeeded.length)
					break;

			}
		}
		
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("a.cart-icon")).click();
		driver.findElement(By.xpath("//button[contains(text(),'PROCEED TO CHECKOUT')]")).click();

	}

}
