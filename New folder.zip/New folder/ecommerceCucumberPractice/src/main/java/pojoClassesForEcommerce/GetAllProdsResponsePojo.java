package pojoClassesForEcommerce;

import java.util.List;

public class GetAllProdsResponsePojo {
	
	private List<Data> data;
	private String count;
	private String message;
	public List<Data> getData() {
		return data;
	}
	public void setData(List<Data> data) {
		this.data = data;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

}
