package stepdefinitionecommerce;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import ecommerceResources.APIResources2;
import ecommerceResources.APIResources2;
import ecommerceResources.DataResource;
import ecommerceResources.Utilities;
import io.restassured.response.Response;
import pojoClassesForEcommerce.GetAllProdsResponsePojo;
import ecommerceResources.APIResources2;

public class StepDefinition extends Utilities {
	Response response;
	// APIResources APIress ;
	DataResource dr = new DataResource();
	String token;
	String userId;
	String productID;

	@Given("User loggedinto application using {string} & {string}")
	public void user_loggedinto_application_using(String username, String password) throws IOException {
		APIResources2 APIress = APIResources2.valueOf("Login");
		response = given().header("Content-Type", "application/json").spec(Baserequest())
				.body(dr.credsRequestBody(username, password)).when().post(APIress.getResource()).then().extract()
				.response();
		token = fetchValuefromResponse(response, "token").toString();
		userId = fetchValuefromResponse(response, "userId").toString();
		System.out.println(token);
		System.out.println("User is " + userId);

	}

	@When("User is loggedIn create a product with details {string},{string},{string},{string},{string},{string}")
	public void user_is_logged_in_create_a_product_with_details(String productName, String productCategory,
			String productSubCategory, String productPrice, String productDescription, String productFor)
			throws IOException {
		// "<productName>","<productCategory>","<productSubCategory>","<productPrice>","<productDescription>","<productFor>"
		APIResources2 APIress = APIResources2.valueOf("createProduct");
		response = given().spec(Baserequest()).header("Authorization", token).param("productName", productName)
				.param("productAddedBy", userId).param("productCategory", productCategory)
				.param("productSubCategory", productSubCategory).param("productPrice", productPrice)
				.param("productDescription", productDescription).param("productFor", productFor)
				.multiPart("productImage", new File(System.getProperty("user.dir") + "\\laptopImage.png")).when()
				.post(APIress.getResource()).then().extract().response();

		productID = fetchValuefromResponse(response, "productId").toString();

	}

	@Then("{string} is succesfully added in the productList")
	public void user_is_succesfully_added_in_the_product_list(String productname) throws IOException {
		APIResources2 APIress = APIResources2.valueOf("GetAllPros");
		GetAllProdsResponsePojo getAllprods = given().spec(Baserequest()).header("Content-Type", "application/json")
				.body(new String(Files.readAllBytes(Paths.get(System.getProperty("user.dir")
						+ "\\src\\test\\java\\ecommerceResources\\AllproductreqBody.json"))))
				.header("Authorization", token).when().post(APIress.getResource()).then().extract().response()
				.as(GetAllProdsResponsePojo.class);
		// System.out.println(productname);
		assertTrue(getAllprods.getData().stream().anyMatch(s -> s.getProductName().contains(productname)));

	}

	@And("{string} is then deleted succesfully")
	public void product_is_deleted(String productname) throws IOException {
		APIResources2 APIress = APIResources2.valueOf("DeleteProduct");
		given().urlEncodingEnabled(false).spec(Baserequest()).header("Authorization", token)
				.pathParam("proid", productID).when().delete(APIress.getResource() + "{proid}");

	}

	@And("User is able to create an order for {string} with Country {string}")
	public void userIsAbleToCreateAnOrder(String productName, String country) throws IOException {
		APIResources2 apires = APIResources2.valueOf("CreateOrder");
		given().header("Content-Type", "application/json")  .header("Authorization", token).spec(Baserequest()).urlEncodingEnabled(false)
				.body(dr.createProductRequestBody(country, productID)).when().post(apires.getResource());

	}

}
