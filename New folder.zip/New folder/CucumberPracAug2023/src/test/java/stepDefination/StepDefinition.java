package stepDefination;

import org.junit.runner.RunWith;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

//@RunWith(Cucumber.class)
public class StepDefinition {
	
	
	@Given("User is on landing page")
    public void user_is_on_landing_page() {
        // Add code to navigate to the landing page
		System.out.println("User is succesfully landed on landing page ");
    }

    @When("user login into application with username and password")
    public void user_login_into_application_with_username_and_password() {
        // Add code to perform the login with username and password
    	System.out.println("User successfully logged in ");
    }

    @Then("Home page is displayed")
    public void home_page_is_displayed() {
        // Add code to verify that the home page is displayed
    	System.out.println("Home page is succesfully displayed");
    }

    @And("Users cards are displayed")
    public void users_cards_are_displayed() {
        // Add code to verify that user cards are displayed on the home page
    	System.out.println("user cards are succefully displayed");
    }
    
    @When("user login into application with {string} and {string}")
    public void user_login_into_application_with_username_and_password(String username, String password) {
        // Add code to perform the login with the provided username and password
        // In this step, 'username' will be "randomuser" and 'password' will be "WrongPassword"
        // You can use these values to log in and perform the necessary verifications
    	System.out.println(username);
    	System.out.println(password);
    	if(username.contains("random")) {
    		System.out.println("not allowd");
    	}else
    		System.out.println("login allowed");	
    }
    
    @Then("Users cards are displayed {string}")
    public void users_cards_are_displayed(String displayedValue) {
    	System.out.println(displayedValue);
        
    }
	
	

}
