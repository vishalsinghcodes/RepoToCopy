package cucumberOptions;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		
		features = "src\\test\\java\\features\\Login.feature", // If you will give exact name of the feature																		// file then only that feature file will run
		// But if you want to run all the feature files, you will give location till
		// package. - src\\test\\java\\features
		glue = "stepDefination"
// In glue you just need to give the name of the package but remember that, the
// package in which this test runner is created is same and the package in which
// step definition is present should have same parent if it is not done you will need to give the exact location till the package of step definition
)

public class TestRunner {

}
