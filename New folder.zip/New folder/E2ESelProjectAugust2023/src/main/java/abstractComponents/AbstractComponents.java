package abstractComponents;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import E2ESelTestPackage.PageObjects.CartPage;
import E2ESelTestPackage.PageObjects.OrderHistoryPage;

public class AbstractComponents {

	WebDriver driver;

	protected AbstractComponents(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//button[@routerlink='/dashboard/cart']")
	WebElement cartLink;
	
	@FindBy(xpath="//button[@routerlink='/dashboard/myorders']")
	WebElement myOrders;

	public CartPage goToCartPage() {
		cartLink.click();
		CartPage cartPage = new CartPage(driver);
		return cartPage;
	}
	
	public OrderHistoryPage goToMyOrders() {
		myOrders.click();
		OrderHistoryPage orderHistoryPage= new OrderHistoryPage(driver);
		return orderHistoryPage;
	}

	public void waitForElementsToBeVisible(By findBy) { // Elements
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(findBy));
	}
	
	public void waitForElementToBeVisible(WebElement ele) { // Element
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.visibilityOf(ele));
	}

	public void waitForElementsToBeInvisible(By findBy) {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.invisibilityOfElementLocated(findBy));
	}

}
