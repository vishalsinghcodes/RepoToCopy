package E2ESelTestPackage.PageObjects;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import abstractComponents.AbstractComponents;

public class ProductCataloguePage extends AbstractComponents{

	private WebDriver driver;

	public ProductCataloguePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(xpath="//div[@class='card-body']")
	List<WebElement> prodlistEles;
	
	By prodlistBy = By.xpath("//div[@class='card-body']");
	By toastMessage = By.cssSelector("#toast-container");
	By circleEle = By.cssSelector(".ng-tns-c31-0.ng-star-inserted");
	
	
	
	public List<WebElement> getProductListEles() {
		waitForElementsToBeVisible(prodlistBy);
		return prodlistEles;
	}
	
	
	public void Buy(String proName) {
		getProductListEles().stream().filter(s -> s.findElement(By.tagName("b")).getText().contains(proName)).map(s -> {
			WebElement ele = s.findElement(By.xpath("button[2]"));
			return ele;
		}).collect(Collectors.toList()).get(0).click();
		waitForElementsToBeVisible(toastMessage);
		waitForElementsToBeInvisible(circleEle);
	}

	public void verifyProductInCart(String pro) {
		
	}
}
