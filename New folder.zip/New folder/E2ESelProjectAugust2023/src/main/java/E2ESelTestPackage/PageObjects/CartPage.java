package E2ESelTestPackage.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import abstractComponents.AbstractComponents;

public class CartPage extends AbstractComponents {
	private WebDriver driver;

	@FindBy(xpath = "//button[text()='Checkout']")
	WebElement Checkoutbutton;

	@FindBy(xpath = "//div[@class='infoWrap']//h3")
	List<WebElement> prodInCartEle;

	public boolean verifyProduct(String pro) {
		return prodInCartEle.stream().anyMatch(s -> s.getText().contains(pro));
	}
	
	public ConfirmationPage checkOut() {
		Checkoutbutton.click();
		ConfirmationPage confirmationPage = new ConfirmationPage(driver);
		return confirmationPage;
	}

	public CartPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

}
