package E2ESelTestPackage;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByTagName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import E2ESelTestPackage.PageObjects.CartPage;
import E2ESelTestPackage.PageObjects.ConfirmationPage;
import E2ESelTestPackage.PageObjects.FinalPage;
import E2ESelTestPackage.PageObjects.LandingPage;
import E2ESelTestPackage.PageObjects.OrderHistoryPage;
import E2ESelTestPackage.PageObjects.ProductCataloguePage;
import e2ESelProject.TestComponents.BaseTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

import static org.openqa.selenium.support.locators.RelativeLocator.*;

public class StandAloneTestforEditing extends BaseTest {
String productName = "ZARA";

	@Test( groups = {"error-handeling"})
	public void SumitOrderTest() throws IOException, InterruptedException {

		ProductCataloguePage productCataloguePage = landingPage.loginApplication("Udemyselenium@gmail.com",
				"Password1234");
		productCataloguePage.Buy(productName);
		CartPage cartPage = productCataloguePage.goToCartPage();
		System.out.println(cartPage.verifyProduct("ZARA"));
		Assert.assertTrue(cartPage.verifyProduct("ZARA"));
		ConfirmationPage confirmationPage = cartPage.checkOut();
		confirmationPage.textInCountryTextBox("Ind");
		confirmationPage.selectCountry("India");
		Thread.sleep(2000);
		FinalPage finalPage = confirmationPage.placeOrderButtonPress();
		Assert.assertTrue(finalPage.verifyHeaderText("THANKYOU FOR THE ORDER."));
		System.out.println("Order placed");

	}

	@Test(dependsOnMethods = { "SumitOrderTest" })
	public void orderHistoryTest() throws InterruptedException {
		ProductCataloguePage productCataloguePage = landingPage.loginApplication("Udemyselenium@gmail.com", "Password1234");
		OrderHistoryPage orderHistoryPage = productCataloguePage.goToMyOrders();
		orderHistoryPage.verifyProduct(productName);
		Thread.sleep(3000);
	}

}
