package E2ESelTestPackage;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByTagName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import E2ESelTestPackage.PageObjects.CartPage;
import E2ESelTestPackage.PageObjects.ConfirmationPage;
import E2ESelTestPackage.PageObjects.FinalPage;
import E2ESelTestPackage.PageObjects.LandingPage;
import E2ESelTestPackage.PageObjects.ProductCataloguePage;
import e2ESelProject.TestComponents.BaseTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

import static org.openqa.selenium.support.locators.RelativeLocator.*;

public class ErrorValidationTest extends BaseTest {

	@Test( groups = {"error-handeling"})
	public void loginErrorToastValidation() throws IOException, InterruptedException {

		// To login with incorrect email
		landingPage.loginApplication("WrongID@gmail.com", "PasswordWrong");
		Assert.assertEquals(landingPage.getErrorMessage(), "Incorrect email or password.");
		;

	}

	@Test
	public void ProductAddedValidationTest() throws IOException, InterruptedException {
		ProductCataloguePage productCataloguePage = landingPage.loginApplication("rahulshetty@gmail.com",
				"Iamking@000"); // we have used different login credentials because when we will run wih
		productCataloguePage.Buy("ZARA");
		CartPage cartPage = productCataloguePage.goToCartPage();
		System.out.println(cartPage.verifyProduct("ZARA"));
		Assert.assertFalse(cartPage.verifyProduct("ADIDAS")); // Wrong product to verify to make this test fail.

	}

}
