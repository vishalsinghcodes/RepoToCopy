package E2ESelTestPackage;

import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByTagName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import E2ESelTestPackage.PageObjects.LandingPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

import static org.openqa.selenium.support.locators.RelativeLocator.*;

public class StandAloneTest {

	public static void main(String[] args) throws InterruptedException {
		
		
		
		String product = "ADIDAS";
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		LandingPage landingPage = new LandingPage(driver); // Object created for landing page & will be created after creating driver as above
		
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		driver.get("https://www.rahulshettyacademy.com/client");
		driver.findElement(By.cssSelector("#userEmail")).sendKeys("Udemyselenium@gmail.com");
		driver.findElement(By.id("userPassword")).sendKeys("Password1234");
		driver.findElement(By.id("login")).click();
		w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='card-body']")));
		List<WebElement> prodcards = driver.findElements(By.xpath("//div[@class='card-body']"));
		prodcards.stream().filter(s -> s.findElement(By.tagName("b")).getText().contains(product)).map(s -> {
			WebElement ele = s.findElement(By.xpath("button[2]"));
			return ele;
		}).collect(Collectors.toList()).get(0).click();

		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.cssSelector("#toast-container"))));
		w.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".ng-tns-c31-0.ng-star-inserted")));
		driver.findElement(By.xpath("//button[@routerlink='/dashboard/cart']")).click();

		List<WebElement> productsInCart = driver.findElements(By.xpath("//div[@class='infoWrap']//h3"));
		Assert.assertTrue(productsInCart.stream().anyMatch(s -> s.getText().contains(product)));
		System.out.println("Item added to cart");
		driver.findElement(By.xpath("//button[text()='Checkout']")).click();

		//driver.findElement(By.xpath("//input[@placeholder='Select Country']")).sendKeys("Ind");
		// This can also be used perfectly working But to make use of actions we are
		// doing below
		Actions a = new Actions(driver);
		a.sendKeys(driver.findElement(By.xpath("//input[@placeholder='Select Country']")), "Ind").build().perform();
		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//section[@class='ta-results list-group ng-star-inserted']"))));
		List<WebElement> country = driver
				.findElements(By.xpath("//button[@class='ta-item list-group-item ng-star-inserted']/span"));
		country.stream().filter(s->s.getText().equalsIgnoreCase("Indonesia")).collect(Collectors.toList()).get(0).click();
		driver.findElement(By.xpath("//a[text()='Place Order ']")).click();
		Assert.assertEquals(driver.findElement(By.cssSelector(".hero-primary")).getText(), "THANKYOU FOR THE ORDER.");
		System.out.println("Order placed");
		driver.close();
		
		
		
		
	}

}
