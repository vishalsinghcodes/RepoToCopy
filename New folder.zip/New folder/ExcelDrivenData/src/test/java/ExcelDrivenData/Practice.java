package ExcelDrivenData;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Practice {

	@Test(dataProvider = "fetchExcelData")
	public void test01(String a, String b, String c) {
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		
	}
	
	
	
	@DataProvider
	public Object[][] fetchExcelData() throws IOException {
		DataFormatter formatter = new DataFormatter();
		String pathToFile = System.getProperty("user.dir") + "\\For Data Deriving Test NG.xlsx";
		FileInputStream fis = new FileInputStream(pathToFile);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		int noOfSheets = workbook.getNumberOfSheets();
		XSSFSheet reqSheet = null;
		for (int i = 0; i < noOfSheets; i++) {
			if(workbook.getSheetName(i).equalsIgnoreCase("Sheet1"))
				reqSheet = workbook.getSheetAt(i);
		}
		XSSFRow firstRow = reqSheet.getRow(0);
		int numberOfRows = reqSheet.getPhysicalNumberOfRows();
		int numberOfCols = firstRow.getLastCellNum();
		Object data[][] = new Object[numberOfRows][numberOfCols];
		for(int i =0;i<numberOfRows;i++) {
			XSSFRow tempRow = reqSheet.getRow(i);
			for(int j =0;j<numberOfCols;j++) {
				XSSFCell cell = tempRow.getCell(j);
				data[i][j] = formatter.formatCellValue(cell);		
			}
		}
		
//		for(int i =0;i<numberOfRows;i++) {
//			for(int j =0;j<numberOfCols;j++) {
//				System.out.println(data[i][j]);
//			}
//		}
	
		return data;

	}

}
