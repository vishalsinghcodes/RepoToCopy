package ExcelDrivenData;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.poi.*;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class IfNumericdata {
	ExtentReports extent;

	@Test
	public void testusingMethod() throws IOException {
		ArrayList<String> data = getdataFromExcel();
		data.stream().forEach(s -> System.out.println(s));

	}

	@BeforeTest
	public void extentReport() {
		File reportpath = new File("D:\\Excel Data Driven Practice\\Report.html");
		ExtentSparkReporter reporter = new ExtentSparkReporter(reportpath);
		reporter.config().setDocumentTitle("Excel Test Results");
		reporter.config().setReportName("Test Result");

		extent = new ExtentReports();
		extent.setSystemInfo("Tester", "Vishal Singh");
		extent.setSystemInfo("Testing env", "UAT");
		extent.attachReporter(reporter);

	}

	@AfterTest
	public void aftertest() {
		extent.flush();
	}

	public ArrayList<String> getdataFromExcel() throws IOException {
		ArrayList<String> arl = new ArrayList<String>();
		ExtentTest test = extent.createTest("Test 01");
		FileInputStream fis = new FileInputStream("D:\\Excel Data Driven Practice\\TestExcel.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		int noOfSheets = workbook.getNumberOfSheets();
		System.out.println("Number of sheets found in Excel : " + noOfSheets);
		for (int i = 0; i < noOfSheets; i++) {
			if (workbook.getSheetName(i).equalsIgnoreCase("TestDataSheet01")) {
				XSSFSheet requiredSheet = workbook.getSheetAt(i);
				Iterator<Row> rowit = requiredSheet.rowIterator();
				Row firstRow = rowit.next();
				Iterator<Cell> cellit = firstRow.cellIterator();
				int k = 0;
				int column = 0;
				while (cellit.hasNext()) {
					Cell value = cellit.next();
					if (value.getStringCellValue().equalsIgnoreCase("Test Cases"))
						column = k;
					k++;
				}
				System.out.println(column);
				while (rowit.hasNext()) {
					Row r = rowit.next();
					if (r.getCell(column).getStringCellValue().equalsIgnoreCase("Numeric have")) {
						Iterator<Cell> cit = r.cellIterator();
						while (cit.hasNext()) {
							Cell c = cit.next();
							if (c.getCellType() == CellType.STRING) {
								arl.add(c.getStringCellValue());
							} else
								arl.add(NumberToTextConverter.toText(c.getNumericCellValue()));
						}

					}
				}
			}
			test.log(Status.PASS, "Test Passed");

		}
		return arl;
	}
}
