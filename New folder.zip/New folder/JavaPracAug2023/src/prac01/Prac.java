package prac01;

import java.util.ArrayList;
import java.util.List;

public class Prac {

	public static void main(String agrg[]) {
		
		String a = "Vishal";
		List<String> list = new ArrayList<String>();
		list.add(a);
		String rev = new StringBuilder(a).reverse().toString();
		System.out.println(rev);
	
	
	}

	
	
	
}
