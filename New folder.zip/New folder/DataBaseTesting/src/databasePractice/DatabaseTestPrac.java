package databasePractice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DatabaseTestPrac {

	@Test(dataProvider = "getdata", enabled = true)
	public void someMethod(String a, String b) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.rahulshettyacademy.com/loginpagePractise/");
		driver.findElement(By.id("username")).sendKeys(a);
		driver.findElement(By.id("password")).sendKeys(b);
		Thread.sleep(2000);
		driver.close();

	}

	@DataProvider
	public Object[][] getdata() throws SQLException, InterruptedException {
		String host = "localhost";
		String port = "3306";

		Connection dbcon = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/demoprojectqadb", "root",
				"Nokia@4230");
		Statement statement = dbcon.createStatement();	
		ResultSet rowcount = statement.executeQuery("SELECT COUNT(*) as countresult FROM employeeinfo WHERE age > 20");
		rowcount.next();
		String numberOfRows = rowcount.getString("countresult");
		//System.out.println(numberOfRows);
		int totalrows =  Integer.parseInt(numberOfRows);
		int numberOfCols = 2; // we know as in query also we are selecting only name and ID
		Object data[][] = new Object[totalrows][numberOfCols];
		ResultSet rs = statement.executeQuery("select * from EmployeeInfo where age > 20");
		for (int i = 0; i < totalrows; i++) {
			rs.next();
			for (int j = 0; j < numberOfCols; j++) {
				//System.out.println("Here");
				
				data[i][0] = rs.getString("name");
				data[i][1] = rs.getString("id");
			}
			
		}

		return data;
	}
	
	@Test(enabled = false)  // Just to test if data provided is correct. - Not an actual test
	public void getdatatest() throws SQLException, InterruptedException {
		String host = "localhost";
		String port = "3306";

		Connection dbcon = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/demoprojectqadb", "root",
				"Nokia@4230");
		Statement statement = dbcon.createStatement();
		
		ResultSet rowcount = statement.executeQuery("SELECT COUNT(*) as countresult FROM employeeinfo WHERE age > 20");
		rowcount.next();
		String numberOfRows = rowcount.getString("countresult");
		System.out.println(numberOfRows);
		int totalrows =  Integer.parseInt(numberOfRows);
		int numberOfCols = 2; // we know
		Object data[][] = new Object[totalrows][numberOfCols];
		ResultSet rs = statement.executeQuery("select * from EmployeeInfo where age > 20");
		for (int i = 0; i < totalrows; i++) {
			rs.next();
			for (int j = 0; j < 2; j++) {
				//System.out.println("Here");
				
				data[i][0] = rs.getString("name");
				data[i][1] = rs.getString("id");
			}
			
		}
		for (int i = 0; i < totalrows; i++) {
			for (int j = 0; j < 2; j++) {
				//System.out.println("Here");
				System.out.println(data[i][j] );
				
			}
			
		}
		

		
	}

}
