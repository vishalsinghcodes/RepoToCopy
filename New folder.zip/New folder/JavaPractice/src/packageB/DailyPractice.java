package packageB;

public class DailyPractice {

	public static void main(String args[]) {
		System.out.println("Vishal Singh");
		
	}

}
