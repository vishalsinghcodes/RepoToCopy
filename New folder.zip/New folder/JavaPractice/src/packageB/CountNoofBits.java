package packageB;

import java.util.Scanner;

public class CountNoofBits {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int a = scn.nextInt();
		int count = 0;
		while (a > 0) {
			count += a & 1;
			a >>= 1;
		}
		System.out.print(count);
	}

}
