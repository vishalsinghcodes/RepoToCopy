package packageB;

public class BinaryToDecimal {

	public static void main(String[] args) {
		int a = 110000;
		
		int temp = a;
		int base = 1;
		int decimal = 0;
		while(temp!=0) {
			int lastdig = temp%10;
			
			decimal += base*lastdig;
			base *=2;
			temp/=10;
			
			
		}
		
		System.out.print(decimal);

	}

}