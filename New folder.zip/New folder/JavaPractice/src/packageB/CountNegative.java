package packageB;

public class CountNegative {
	static int count = 0;
	static int negcount ( int arr[],int a, int b) {
		
		if(b<a) {
			if(arr[b]<0)
				count++;
			
			negcount(arr, a, ++b);
		}
		
		
		return count;
		
	}
	
	public static void main(String[] args) {
		int num[] = {1,-9,-8,-6,5,7,4,-58,-69};
		int len = num.length;
		
		System.out.print(negcount(num, len, 0));

	}

}
