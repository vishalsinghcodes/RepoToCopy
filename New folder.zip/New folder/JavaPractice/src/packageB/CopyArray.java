package packageB;

public class CopyArray {

	public static void main(String[] args) {
		char a[] = {'g','o','o','d','m','o','r','n','i','n','g'};
		char b[] = new char[6];
		System.arraycopy(a, 5, b, 0, 6);
		System.out.println(String.valueOf(b));
		
		char f[] = new char[a.length];
		for(int i = 0;i<a.length;i++) {
			f[i] = a[i];
		}
		System.out.println(String.valueOf(f));
		
		char v[] = a.clone();
		System.out.print(String.valueOf(v));

	}

}
