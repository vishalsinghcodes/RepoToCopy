package packageB;

public class Anagram {

	static void swap(char[] arr, int a, int b) {
		char m = arr[a];
		arr[a] = arr[b];
		arr[b] = m;
	}

	static char[] sort(char[] a) {

		int len = a.length;

		for (int i = 0; i < len; i++) {
			int minind = i;
			for (int j = i; j < len; j++) {
				if (a[minind] > a[j])
					minind = j;
			}
			swap(a, i, minind);
		}
		return a;
	}

	static boolean ana(String a, String b) {

		char str1[] = a.toCharArray();
		char str2[] = b.toCharArray();

		if (str1.length != str2.length)
			return false;

		str1 = sort(str1);
		str2 = sort(str2);

		for (int i = 0; i < str1.length; i++) {
			if (str1[i] != str2[i]) {
				return false;
			}
		}
		return true;

	}

	public static void main(String[] args) {

		String a = "treef";
		String b = "eter";

		System.out.println(ana(a, b));

	}

}
