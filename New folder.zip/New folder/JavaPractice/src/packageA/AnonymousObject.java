package packageA;

public class AnonymousObject {
	
	void factorial(int a) {
		int num = 1;
		for (int i = a;i>=2;i--) {
			num*=i;
		}
		System.out.print(num);
	}

	public static void main(String[] args) {
		new AnonymousObject().factorial(5);// here we have not defined any new object variable.

	}

}
