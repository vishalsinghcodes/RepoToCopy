package packageA;

public class Loops {

	public static void main(String[] args) {
		
//		for ( int i = 0; i<=10;i++) {
//			System.out.println(i);
//		}
//		
//		for (int i=1;i<=5;i++) {
//			for( int j = 0;j<i;j++) {
//				System.out.print("*");
//			}
//			System.out.println("");
//		}

		// For each 
		
		int a[] = {12,35,56,43,87};		for (int b :a) {
			if(b%2==0) {
				System.out.println(b+" is even");
			}else {
				System.out.println(b+ " is Odd");
			}
		}
		
		
		
	}

}
