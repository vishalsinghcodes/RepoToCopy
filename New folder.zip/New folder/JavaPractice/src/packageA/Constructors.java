package packageA;

public class Constructors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
