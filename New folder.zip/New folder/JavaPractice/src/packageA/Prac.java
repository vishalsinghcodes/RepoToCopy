package packageA;

public class Prac {

	public static void main(String args[]) {
		int num1 = 12333;
		int numbTobeReplaced = 3;
		int numberreplacing = 7;
		int result = 0;
		int multiplier = 1;
		int digit = 0;
		while (num1 > 0) {
			digit = num1 % 10;
			if (digit == numbTobeReplaced) {
				digit = numberreplacing;
			}
			result = result + multiplier * digit;
			multiplier *= 10;
			num1 /= 10;
		}
		System.out.println(result);

	}

}
