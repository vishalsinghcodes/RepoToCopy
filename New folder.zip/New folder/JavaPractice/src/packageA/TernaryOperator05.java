package packageA;

public class TernaryOperator05 {

	public static void main(String[] args) {
		int a = 5;
		int b = 6 ;
		
		int c = a<b?(a+b):b;
		System.out.print(c);
		

	}

}
