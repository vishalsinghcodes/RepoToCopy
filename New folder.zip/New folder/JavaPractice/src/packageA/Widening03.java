package packageA;

import java.util.Scanner;

public class Widening03 {
	
	public static void main(String arg[]) {
		Scanner scn = new Scanner(System.in);
		int a = scn.nextInt();
		
		float f = a;
		System.out.print(f);
		
	}

}
