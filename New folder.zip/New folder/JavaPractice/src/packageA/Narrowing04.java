package packageA;

import java.util.Scanner;

public class Narrowing04 {
	public static void main(String arg[]) {
		
		Scanner scn = new Scanner(System.in);
		float f = scn.nextFloat();
		System.out.println("Float number entered : ");
		System.out.println(f); 
		
		int a = (int)f;
		System.out.println(a);
		
		
		
	}

}
