package packageA;


class account{
	int accNo;
	String Name;
	double amount;
	
	void insertdetails(int a, String b, double c) {
		this.accNo = a;
		this.Name = b;
		this.amount = c;
	}
	
	void showdetails() {
		System.out.println(this.accNo);
		System.out.println(this.Name);
		System.out.println(this.amount);
	}
	
	void deposit(double d) {
		this.amount += d;
		System.out.println(d+"deposited");
	}
	
	void withdraw(double d) {
		if (d> this.amount ) {
			System.out.println("You don't have sufficient balance to withdraw");
			System.out.println("available balance = "+this.amount);
		}else {
			this.amount -=d;
			System.out.println(d+"debited");
		}
	}
	
	
}

public class ATMApplication {
	
	public static void main(String[] args) {
		account a1 = new account();
		a1.insertdetails(123, "Vishal", 12345.21);
		a1.showdetails();
		a1.deposit(1245.33);
		a1.showdetails();
		a1.withdraw(144785255.0);
		
		
		

	}

}
